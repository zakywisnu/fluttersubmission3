class Meal {
  String idMeal,
      strMeal,
      strMealThumb;


  Meal(
      {this.idMeal,
      this.strMeal,
      this.strMealThumb,
      });
  factory Meal.fromJson(Map<String, dynamic> json){
    return Meal(
      idMeal: json['idMeal'] as String,
      strMeal: json['strMeal'] as String,
      strMealThumb: json['strMealThumb'] as String,
    );
  }
}
