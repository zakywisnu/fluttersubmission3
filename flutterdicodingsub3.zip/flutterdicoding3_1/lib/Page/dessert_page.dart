import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutterdicoding3/Model/meal.dart';
import 'package:flutterdicoding3/View/detail_screen.dart';
import 'package:http/http.dart' as http;

class DessertPage extends StatefulWidget {
  DessertPage({Key key}) : super(key: key);

  @override
  _desertState createState() => _desertState();
}

class _desertState extends State<DessertPage> {
  Future<List<Meal>> meals;

  @override
  void initState() {
    super.initState();
    meals = fetchMeals(http.Client());
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Meal>>(
      future: meals,
      builder: (context, snapshot) {
        if (snapshot.hasError) print(snapshot.error);
        return snapshot.hasData
            ? DessertList(meals: snapshot.data)
            : Center(
                child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.black)),
              );
      },
    );
  }
}

class DessertList extends StatelessWidget {
  final List<Meal> meals;

  DessertList({Key key, this.meals}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount:
              MediaQuery.of(context).orientation == Orientation.portrait
                  ? 2
                  : 3),
      padding: EdgeInsets.all(10.0),
      itemCount: meals.length,
      itemBuilder: (context, index) {
        return Container(
          padding: EdgeInsets.all(10.0),
          child: Card(
            child: Column(
              children: <Widget>[
                Expanded(
                  child: Hero(
                    tag: meals[index],
                    child: Material(
                      child: InkWell(
                        onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => DetailScreen(
                                      meal: meals[index],
                                    ))),
                        child: Image.network(meals[index].strMealThumb,
                            width: double.infinity,
                            height: double.infinity,
                            fit: BoxFit.fill),
                      ),
                    ),
                  ),
                ),
                Padding(padding: EdgeInsets.all(10.0)),
                Text(
                  meals[index].strMeal,
                  style: TextStyle(fontSize: 20.0),
                )
              ],
            ),
          ),
        );
      },
    );
  }
}

class DessertResponse {
  List<Meal> meals;

  DessertResponse(this.meals);

  DessertResponse.fromJson(Map<String, dynamic> json) {
    if (json['meals'] != null) {
      meals = List<Meal>();
      json['meals'].forEach((v) {
        meals.add(Meal.fromJson(v));
      });
    }
  }
}

List<Meal> parseMeals(String responseBody) {
  final responseJson = json.decode(responseBody);
  final dessertResponse = DessertResponse.fromJson(responseJson);
  return dessertResponse.meals;
}

Future<List<Meal>> fetchMeals(http.Client client) async {
  final response = await client
      .get('https://www.themealdb.com/api/json/v1/1/filter.php?c=Dessert');
  if (response.statusCode == 200) {
    return compute(parseMeals, response.body);
  } else {
    throw Exception("Failed to load data!");
  }
}
