import 'package:flutter/material.dart';
import 'package:flutterdicoding3/Page/dessert_page.dart';
import 'package:flutterdicoding3/Page/seafood_page.dart';


class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            bottom: TabBar(
              tabs: <Widget>[
                Tab(text: "Dessert",),
                Tab(text: "Seafood",)
              ],
            ),
            title: Text("Makanan"),
          ),
          body: TabBarView(
            children: <Widget>[
              DessertPage(),
              SeafoodPage(),
            ],
          ),
        ),
      )
      ,
    );
  }


}