import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';

import 'detail_info.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutterdicoding3/Model/detailed_meal.dart';
import 'package:flutterdicoding3/Model/meal.dart';
import 'package:flutterdicoding3/Page/dessert_page.dart';
import 'package:flutterdicoding3/Page/seafood_page.dart';

class DetailScreen extends StatefulWidget {
  final Meal meal;

  DetailScreen({Key key, this.meal}) : super(key: key);
  @override
  DetailScreenState createState() => DetailScreenState();
}

class DetailScreenState extends State<DetailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.meal.strMeal),
      ),
      body: Stack(
        children: <Widget>[
          Align(
            alignment: Alignment.topCenter,
            child: Container(              
              padding: EdgeInsets.only(top: 16.0),
              child: Hero(
                tag: widget.meal.idMeal,
                child: ClipOval(
                  child: CachedNetworkImage(                  
                  imageUrl: widget.meal.strMealThumb,
                  width: 150.0,
                  height: 150.0,
                  fit: BoxFit.cover,
                ),),
              ),
            ),
          ),
          detail(),
        ],
      ),
    );
  }

  Widget detail() {
    return FutureBuilder<List<DetailedMeal>>(
      future: fetchDetailMeals(http.Client(), widget.meal.idMeal),
      builder: (context, snapshot) {
        if (snapshot.hasError) print(snapshot.error);
        return snapshot.hasData
            ? DetailInfo(detailedMeal: snapshot.data)
            : Center(
                child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.black)));
      },
    );
  }
}

class DetailedResponse {
  List<DetailedMeal> detailMeal;
  DetailedResponse(this.detailMeal);
  DetailedResponse.fromJson(Map<String, dynamic> json) {
    if (json['meals'] != null) {
      detailMeal = List<DetailedMeal>();
      json['meals'].forEach((v) {
        detailMeal.add(DetailedMeal.fromJson(v));
      });
    }
  }
}

List<DetailedMeal> parseDetailMeals(String responseBody) {
  final responseJson = json.decode(responseBody);
  final detailResponse = DetailedResponse.fromJson(responseJson);
  return detailResponse.detailMeal;
}

Future<List<DetailedMeal>> fetchDetailMeals(
    http.Client client, String idMeal) async {
  final response = await client
      .get('https://www.themealdb.com/api/json/v1/1/lookup.php?i=$idMeal');
  if (response.statusCode == 200) {
    return compute(parseDetailMeals, response.body);
  } else {
    throw Exception('Failed to load data!');
  }
}
